package StudentInfo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class Staff {
    public void sfview() throws ClassNotFoundException, SQLException {
        String name = null,sid = null,sdob = null,dpt = null,sad = null,qual = null,sph = null,sem = null;
        int sye = 0,syr = 0;
        Scanner sc=new Scanner(System.in);
        Connection con;
        Statement stm;
        PreparedStatement st;
        ResultSet rs;
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        con=DriverManager.getConnection("jdbc:derby://localhost:1527/StudentInfo","admin1","root");
        stm=con.createStatement();
        //st1=con.prepareStatement()
        System.out.println("Enter your name:");
        name=sc.nextLine(); 
        st= con.prepareStatement("select * from Staff where name=?");
      st.setString(1,name);
        rs=st.executeQuery();
        if(rs.next())
        {       
            name=rs.getString(1);
            sid=rs.getString(2);
            sdob=rs.getString(3);
            syr=rs.getInt(4);
            dpt=rs.getString(5);
            qual=rs.getString(6);
            sye=rs.getInt(7);
            sad=rs.getString(8);
            sph=rs.getString(9);
            sem=rs.getString(10);
       }
        System.out.println("Staff Name:"+ name);
        System.out.println("Staff ID No: "+sid);
        System.out.println("Date Of Birth: "+sdob);
        System.out.println("Year Of Joining: "+syr);
        System.out.println("Department: "+dpt);
        System.out.println("Educational Qualification: "+qual);
        System.out.println("Years Of experience "+sye);
        System.out.println("Address: "+sad);
        System.out.println("Phone No: "+sph);
        System.out.println("E-Mail Id: "+sem);
   
    }
}
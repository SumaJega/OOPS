package StudentInfo;
import java.util.*;
import java.sql.*;
public class Registeration
{
    int a,status=1;
    String role, uname,pwd,cpwd;
    Admin ad=new Admin();
    Student s=new Student();
    Staff sf=new Staff();
    void register() throws ClassNotFoundException, SQLException 
    {
        Scanner sc=new Scanner(System.in);
        ArrayList<String> rList=new ArrayList<>();
        rList.add("1.Admin");
        rList.add("2.Student");
        rList.add("3.Staff");
        System.out.println("------------------------------");
        System.out.println("Enter Username:");
        uname=sc.next();
        System.out.println("Enter Password:");
        pwd=sc.next();
        System.out.println("Retype the Password:");    
        cpwd=sc.next();
        while(!pwd.equals(cpwd))
        {    
            System.out.println("Please Enter the password and confirm password correctly");
            System.out.println("Enter Password:");
            pwd=sc.next();
            System.out.println("Retype the Password:");    
            cpwd=sc.next();
        }
        System.out.println(rList);
        System.out.println("Enter your role:");
        a=sc.nextInt();
        switch (a) 
        {
            case 1:
                role="Admin";
                break;
            case 2:
                role="Student";   
                break;
            default:
                role="Staff";
                break;
        }
        Connection con;
        Statement stm;
        PreparedStatement st;
        ResultSet rs;
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        con=DriverManager.getConnection("jdbc:derby://localhost:1527/StudentInfo","admin1","root");
        stm=con.createStatement();
        st= con.prepareStatement("select * from login where uname=? and pwd=?");
        st.setString(1,uname);
        st.setString(2,pwd);
        rs=st.executeQuery();
        if(rs.next())
        {
            System.out.println("Username Already exist");
        }
        else
        {
            String insertQuery="insert into login(uname,pwd,role,status)values(?,?,?,?)";
            st=con.prepareStatement(insertQuery);
            st.setString(1,uname);
            st.setString(2,pwd);
            st.setString(3,role);
            st.setInt(4,status);
            int ins=st.executeUpdate();
            if(ins==1)
            {
                  System.out.println("Registered Succesfully");
            }
         }

    }
    @SuppressWarnings("empty-statement")
   void login() throws ClassNotFoundException, SQLException
   {
       String role=null;
      Scanner sc=new Scanner(System.in);
       System.out.println("------------------------------");
      System.out.println("Enter Username:");
      uname=sc.next();
      System.out.println("Enter Password:");
      pwd=sc.next();    
      Connection con;
      Statement stm;
      PreparedStatement st;
      ResultSet rs;
      Class.forName("org.apache.derby.jdbc.ClientDriver");
      con=DriverManager.getConnection("jdbc:derby://localhost:1527/StudentInfo","admin1","root");
      stm=con.createStatement();
      st= con.prepareStatement("select * from login where uname=? and pwd=?");
      st.setString(1,uname);
      st.setString(2,pwd);
      rs=st.executeQuery();
       if(rs.next())
       {
                       System.out.println("Welcome  "+uname);
                        role=rs.getString(3);
                     System.out.println(role);
     
       }
       else
       {
           System.out.println("Not a Registered user");
       }
        switch (role) {
            case "Admin":
                {
                    int choice,choice1;
                    System.out.println("Hello Admin");
                    ArrayList<String> aList=new ArrayList<>();
                    aList.add("1.Access on Student Details");
                    aList.add("2.Access on Staff Details");
                    do
                    {
                        System.out.println(aList);
                        System.out.println("You would like to access on ???");
                        a = sc.nextInt();
                        switch(a)
                        {
                            case 1:System.out.println("Students Information Block");
                           System.out.println("1.Add Details");
                            System.out.println("2.Delete Details");
                            System.out.println("3.Exit");
                            choice= sc.nextInt();
                            switch(choice)
                            {
                                case 1:ad.stadd();
                                break;
                                case 2:ad.stdelete();
                                break;
                                case 3: System.out.println("Exit");
                                break;
                                default:System.out.println("Invalid choice");
                                break;
                            }
                            break;
                            case 2:System.out.println("Staff Information Block");
                            System.out.println("1.Add Details");
                            System.out.println("2.Delete Details");
                            System.out.println("3.Exit");
                            choice1=sc.nextInt();
                            switch(choice1)
                            {
                                case 1:ad.sfadd();
                                break;
                                case 2:ad.sfdelete();
                                break;
                                case 3: System.out.println("Exit");
                                break;
                                default:System.out.println("Invalid choice");
                                break;
                            }
                            
                            break;
                        }
                    }while(a<=3);
                    break;
                }
            case "Student":
                {
                    int choice,choice1;
                    System.out.println("Hello Student");
                    ArrayList<String> aList=new ArrayList<>();
                    aList.add("1.View your Details");
                    aList.add("2.Exit");
                    do
                    {
                        System.out.println(aList);
                        System.out.println("You would like to access on ???");
                        a = sc.nextInt();
                        switch(a)
                        {
                            case 1:System.out.println("Know About You");
                            s.stview();
                            break;
                            
                        }
                    }while(a<2);break;
                }
            case "Staff":
                {
                    int choice,choice1;
                    System.out.println("Hello Staff");
                    ArrayList<String> aList=new ArrayList<>();
                    aList.add("1.View your Details");
                    aList.add("2.View Student Details");
                    aList.add("3.Exit");
                    do
                    {
                        System.out.println(aList);
                        System.out.println("You would like to access on ???");
                        a = sc.nextInt();
                        switch(a)
                        {
                            case 1:System.out.println("Know About You");
                            sf.sfview();
                            break;
                            case 2:System.out.println("View the Student Details");
                            s.stview();
                        }
                    }while(a<3);
                }
            default:
                break;
        }
   }
}

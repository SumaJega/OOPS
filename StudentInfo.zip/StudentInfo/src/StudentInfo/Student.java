package StudentInfo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class Student {
    public void stview() throws ClassNotFoundException, SQLException {
        String name = null,rno = null,spec = null,fname = null,ad = null,dob = null,ph = null,h = null,em = null;
        int reg = 0,yr = 0;
        double cgpa = 0;
        Scanner sc=new Scanner(System.in);
        Connection con;
        Statement stm;
        PreparedStatement st;
        ResultSet rs;
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        con=DriverManager.getConnection("jdbc:derby://localhost:1527/StudentInfo","admin1","root");
        stm=con.createStatement();
        //st1=con.prepareStatement()
        System.out.println("Enter your name:");
        name=sc.nextLine(); 
        st= con.prepareStatement("select * from Student where name=?");
      st.setString(1,name);
        rs=st.executeQuery();
        if(rs.next())
        {       
            name=rs.getString(1);
            rno=rs.getString(2);
            reg=rs.getInt(3);
            dob=rs.getString(4);
            yr=rs.getInt(5);
            spec=rs.getString(6);
            fname=rs.getString(7);
            ad=rs.getString(8);
            h=rs.getString(9);
            cgpa=rs.getDouble(10);
            ph=rs.getString(11);
            em=rs.getString(12);
       }
        System.out.println("Student Name:"+ name);
        System.out.println("Roll No: "+rno);
        System.out.println("Registration No: "+reg);
        System.out.println("Date Of Birth: "+dob);
        System.out.println("Year Of Joining: "+yr);
        System.out.println("Specification: "+spec);
        System.out.println("Father's Name: "+fname);
        System.out.println("Address: "+ad);
        System.out.println("Hostel/Dayscholar(H/D): "+h);
        System.out.println("CGPA: "+cgpa);
        System.out.println("Phone No: "+ph);
        System.out.println("E-Mail Id: "+em);
   
    }
}
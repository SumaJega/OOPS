/*      
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package StudentInfo;
import java.sql.*;
import java.util.*;
/**
 *
 * @author 17uite019
 */
public class StudentInfo
    {
    /**
     * @param args the command line arguments
     * @throws java.lang.ClassNotFoundException
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws ClassNotFoundException, SQLException 
    {
      int choice;
      Scanner sc=new Scanner(System.in);
      Registeration  r=new Registeration();
      Admin ad=new Admin();
       do{
       System.out.println("------Student Information System------");
       System.out.println("1.Sign Up");
       System.out.println("2.Log In");
       System.out.println("3.Exit");
       System.out.println("--------------------------------------");
       System.out.println("Enter your choice:");
       choice=sc.nextInt();
       switch(choice)
       {
            case 1:
                       System.out.println("Register");
                       r.register();
                       break;
            case 2:
                       System.out.println("Login");
                       r.login();  
                       
                        break;
                   }
       }while(choice<=2);
    }
}    

package StudentInfo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Admin {
   int a,status=1;
    String role, uname,pwd,cpwd;
    public void stadd() throws ClassNotFoundException, SQLException {
        String name,rno,spec,fname,ad,dob,ph,h,em;
        int reg,yr;
        double cgpa;
        Scanner s=new Scanner(System.in);
        System.out.println("Student Name: ");
        name=s.next();
        System.out.println("Roll No: ");
        rno=s.next();
        System.out.println("Registration No: ");
        reg=s.nextInt();
        System.out.println("Date Of Birth: ");
        dob=s.next();
        System.out.println("Year Of Joining: ");
        yr=s.nextInt();
        System.out.println("Specification: ");
        spec=s.next();
        System.out.println("Father's Name: ");
        fname=s.next();
        System.out.println("Address: ");
        ad=s.next();
        System.out.println("Hostel/Dayscholar(H/D): ");
        h=s.next();
        System.out.println("CGPA: ");
        cgpa=s.nextDouble();
        System.out.println("Phone No: ");
        ph=s.next();
        System.out.println("E-Mail Id: ");
        em=s.next();
        Connection con;
        Statement stm;
        PreparedStatement st;
        ResultSet rs;
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        con=DriverManager.getConnection("jdbc:derby://localhost:1527/StudentInfo","admin1","root");
        stm=con.createStatement();
        String insertQuery;
        insertQuery = "insert into Student(name,rno,reg,dob,yr,spec,fname,ad,h,cgpa,ph,em)values(?,?,?,?,?,?,?,?,?,?,?,?)";
        st=con.prepareStatement(insertQuery);
        st.setString(1,name);
        st.setString(2,rno);
        st.setInt(3,reg);
        st.setString(4,dob);
        st.setInt(5,yr);
        st.setString(6,spec);
        st.setString(7,fname);
        st.setString(8,ad);
        st.setString(9,h);
        st.setDouble(10,cgpa);
        st.setString(11,ph);
        st.setString(12,em);
        int ins=st.executeUpdate();
        if(ins==1)
        {
              System.out.println("Data Inserted Succesfully");
        }
    }
    public void stdelete() throws ClassNotFoundException, SQLException {
        String name ,rno;    
        Scanner s=new Scanner(System.in);
        System.out.println("Student Name: ");
        name=s.next();
        System.out.println("Roll No: ");
        rno=s.next();
        Connection con;
        Statement stm;
        PreparedStatement st;
        ResultSet rs;
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        con=DriverManager.getConnection("jdbc:derby://localhost:1527/StudentInfo","admin1","root");
        stm=con.createStatement();
        String deleteQuery;
        deleteQuery = "delete from Student where name=? and rno=?";
        st=con.prepareStatement(deleteQuery);
        st.setString(1,name);
        st.setString(2,rno);
        int ins=st.executeUpdate();
        if(ins==1)
        {
              System.out.println("Data Deleted Succesfully");
        }
    }    
    public void sfadd() throws ClassNotFoundException, SQLException {
        String name,sid,dpt,qual,sad,sdob,sph,sem;
        int sye,syr;
        Scanner s=new Scanner(System.in);
        System.out.println("Staff Name: ");
        name=s.next();
        System.out.println("Staff id: ");
        sid=s.next();
        System.out.println("Date Of Birth: ");
        sdob=s.next();
        System.out.println("Year Of Joining: ");
        syr=s.nextInt();
        System.out.println("Department: ");
        dpt=s.next();
        System.out.println("Education Qualifiction: ");
        qual=s.next();
        System.out.println("Years Of Experience: ");
        sye=s.nextInt();
        System.out.println("Address: ");
        sad=s.next();
        System.out.println("Phone No: ");
        sph=s.next();
        System.out.println("E-Mail Id: ");
        sem=s.next();
        Connection con;
        Statement stm;
        PreparedStatement st;
        ResultSet rs;
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        con=DriverManager.getConnection("jdbc:derby://localhost:1527/StudentInfo","admin1","root");
        stm=con.createStatement();
        String insertQuery;
        insertQuery = "insert into Staff(name,sid,sdob,syr,dpt,qual,sye,sad,sph,sem)values(?,?,?,?,?,?,?,?,?,?)";
        st=con.prepareStatement(insertQuery);
        st.setString(1,name);
        st.setString(2,sid);
        st.setString(3,sdob);
        st.setInt(4,syr);
        st.setString(5,dpt);
        st.setString(6,qual);
        st.setInt(7,sye);
        st.setString(8,sad);
        st.setString(9,sph);
        st.setString(10,sem);
        int ins=st.executeUpdate();
        if(ins==1)
        {
              System.out.println("Data Inserted Succesfully");
        }
    }
    public void sfdelete() throws ClassNotFoundException, SQLException {
        String name ,sid;    
        Scanner s=new Scanner(System.in);
        System.out.println("Student Name: ");
        name=s.next();
        System.out.println("Staff Id: ");
        sid=s.next();
        Connection con;
        Statement stm;
        PreparedStatement st;
        ResultSet rs;
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        con=DriverManager.getConnection("jdbc:derby://localhost:1527/StudentInfo","admin1","root");
        stm=con.createStatement();
        String deleteQuery;
        deleteQuery = "delete from Staff where name=? and sid=?";
        st=con.prepareStatement(deleteQuery);
        st.setString(1,name);
        st.setString(2,sid);
        int ins=st.executeUpdate();
        if(ins==1)
        {
              System.out.println("Data Deleted Succesfully");
        }
    }
}
